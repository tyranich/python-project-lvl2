from gendiff import gendiff

path1 = "C:/Users/tyran/python-project-lvl2/first_file.json"
path2 = "C:/Users/tyran/python-project-lvl2/second_file.json"
def test_default():
    test_first = gendiff.generate_diff(path1, path2)
    print(type(test_first))